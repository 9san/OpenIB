<?php
	require 'inc/functions.php';
	
	if ($config['gallery']['enable']) {
		die(_("Gallery is disabled"));
	}
	
	if (isset($config['gallery']['boards'])) {
		$boards = $config['gallery']['boards'];
	} else {
		$boards = listBoards(TRUE, TRUE);
	}
	
	$body = Element('8chan/gallery_form.html', Array('boards' => $boards, 'b' => isset($_GET['board']) ? $_GET['board'] : false));
	
	if(isset($_GET['board']) && !empty($_GET['board']) && (in_array($_GET['board'], $boards) || ($_GET['board'] == 'all'))) {		
		$phrase = $_GET['search'];
		$_body = '';

		//TO DO: everything


		$body .= '<hr/>';
		if(!empty($_body))
			$body .= $_body;
		else
			$body .= '<p style="text-align:center" class="unimportant">('._('No images.').')</p>';
	}
		
	echo Element('page.html', Array(
		'config'=>$config,
		'boardlist' => createBoardlist(),
		'title'=>_('Gallery'),
		'body'=>'' . $body
	));
