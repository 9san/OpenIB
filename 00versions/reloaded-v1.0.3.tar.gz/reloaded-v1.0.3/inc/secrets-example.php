<?php

$config['db']['server'] = 'localhost';
$config['db']['database'] = 'openib';
$config['db']['prefix'] = '';
$config['db']['user'] = 'username';
$config['db']['password'] = 'password';

//change these to a random thing, preferably somewhat long (32+ chars)
$config['secure_trip_salt'] = 'salt';
$config['cookies']['salt'] = 'salt';
$config['hashSalt'] = "salt";
