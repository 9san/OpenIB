<?php 

	//newest announcement goes on top
	$config['blotter_announcement'][] = '<td class="blotter-date">02/19/20</td><td class="blotter-message">Banner functionality has been created. Board owners have the choice to use global banners, or upload their own.</td>';
	$config['blotter_announcement'][] = '<td class="blotter-date">02/14/20</td><td class="blotter-message">Announcement function has been created.</td>';
