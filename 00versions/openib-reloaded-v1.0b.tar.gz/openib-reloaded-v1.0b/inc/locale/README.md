Please use this interface to submit new translations:

https://www.transifex.com/projects/p/infinity

They will be pulled over time. By the way, copying over those directories
to a vanilla Tinyboard installation will instantly work.
