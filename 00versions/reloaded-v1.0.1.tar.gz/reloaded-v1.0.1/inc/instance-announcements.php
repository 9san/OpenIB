<?php 

	//newest announcement goes on top
	$config['blotter_announcement'][] = '<td class="blotter-date">03/08/20</td><td class="blotter-message">OpenIB-Reloaded Public Beta Release 1.0b is now released. <a href="/news#v1">Read More</a>. </td>';
	$config['blotter_announcement'][] = '<td class="blotter-date">03/01/20</td><td class="blotter-message">With 500 posts on /b/ and nearly a thousand total, our one month anniversary is here!</td>';
	$config['blotter_announcement'][] = '<td class="blotter-date">02/21/20</td><td class="blotter-message">A simple CAPTCHA for all replies has been enabled. <a href="/meta/thread/13">Read more</a>.</td>';
	$config['blotter_announcement'][] = '<td class="blotter-date">02/19/20</td><td class="blotter-message">Banner functionality has been created. Board owners have the choice to use global banners, or upload their own.</td>';
	$config['blotter_announcement'][] = '<td class="blotter-date">02/14/20</td><td class="blotter-message">Announcement function has been created.</td>';
