<?php

	//yeah this needs fixing. bans dont work, post rejection does.

	//Analockman is banned.
	$config['filters'][] = array(
	 	'condition' => array(
	 		'name' => '/analockman/i',
	 		'OP' => false
	 	),
	 	'action' => 'ban',
		'add_note' => true,
	 	'expires' => 60 * 60 * 3,
	 	'reason' => 'Ban evasion.',
		'all_boards' => true,
	);
	
	//And stop talking about him.
	$config['filters'][] = array(
	 	'condition' => array(
	 		'body' => '/analockman/i',
	 		'OP' => false
	 	),
	 	'action' => 'reject',
	 	'message' => 'Your post has been rejected.'
	);
	$config['filters'][] = array(
	 	'condition' => array(
	 		'name' => '/analockman/i',
	 		'OP' => false
	 	),
	 	'action' => 'reject',
	 	'message' => 'Your post has been rejected.'
	);
	
	//openchan spam
	$config['filters'][] = array(
	 	'condition' => array(
	 		'body' => '/openchan/i',
	 		'OP' => true
	 	),
	 	'action' => 'reject',
	 	'message' => 'Your post has been rejected.'
	);
	$config['filters'][] = array(
	 	'condition' => array(
	 		'body' => '/openchan/i',
	 		'OP' => false
	 	),
	 	'action' => 'reject',
	 	'message' => 'Your post has been rejected.'
	);