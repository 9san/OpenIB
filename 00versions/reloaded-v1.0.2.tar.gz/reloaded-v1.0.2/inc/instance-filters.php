<?php

	//yeah this needs fixing. bans dont work (likely due to no secure_link?), post rejection does work.

	//Analockman is banned. (bans r broken)
	$config['filters'][]=array('condition'=>array('name'=>'/analockman/i'),'action'=>'ban','add_note'=>true,'expires'=>60*60*3,'reason'=>'Ban evasion.','all_boards'=>true,);
	//And stop talking about him.
	$config['filters'][]=array('condition'=>array('body'=>'/analockman/i'),'action'=>'reject','message'=>'Your post has been rejected.');$config['filters'][]=array('condition'=>array('name'=>'/analockman/i'),'action'=>'reject','message'=>'Your post has been rejected.');
	//openchan spam
	$config['filters'][] = array('condition' => array('body' => '/openchan/i'),'action' => 'reject','message' => 'Your post has been rejected.');
	//drug scam spam
	$config['filters'][] = array('condition' => array('body' => '/cnchemx/i'),'action' => 'reject','message' => 'Your post has been rejected.');